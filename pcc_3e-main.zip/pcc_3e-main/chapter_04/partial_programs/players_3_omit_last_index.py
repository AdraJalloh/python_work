players = ['charles', 'martina', 'michael', 'florence', 'eli']
print(players[2:])
